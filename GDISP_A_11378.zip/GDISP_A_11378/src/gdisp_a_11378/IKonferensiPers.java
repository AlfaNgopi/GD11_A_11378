package gdisp_a_11378;

public interface IKonferensiPers {
    public void jadwalKonferensiPers();
}
