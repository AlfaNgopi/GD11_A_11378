package gdisp_a_11378;

public interface IJadwal {
    public void jadwalLatihan();
    public void jadwalBertanding();
    
}
