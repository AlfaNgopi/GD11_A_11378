package gdisp_a_11378;

public class GDISP_A_11378 {

    public static void main(String[] args) {
        
        SkuadTim P1 = new SkuadTim("barca","spain","gopa","doplang","4895623");
        PemainUtama DT1 = new PemainUtama("Alfa","20","01/01/2023","01/03/2023", "striker", "Mobil");
        P1.addPemain(DT1);
        PemainPinjaman dt = new PemainPinjaman("asdc","20","01/01/2023","01/03/2023", "arema", 10000);
        P1.addPemain(dt);
        PemainAsing PA = new PemainAsing("asdc","20","01/01/2023","01/03/2023", "argentina", "English");
        P1.addPemain(PA);
        
        
        
        P1.showTim();
        
    }
    
}
